var element = ["A","A","B","B","C","C","D","D","E","E","F","F","G","G","H","H","I","I","J","J","K","K","L","L","M","M","N","N","O","O"];
var elementTileValues = [];
var tileId = [];
var tileFlipped = 0;
var tileClicked = 0;
var value_array =[];


//function to start a timer when the page loads in the webpage
function timer(){
	//adding timer for 59 seconds
var sec = 59;
	//using set interval so that it decrement the seconds after every 1100 milliseconds
	 setInterval(function(){
		document.getElementById("timer").innerHTML = sec;
		//decrementing the seconds 
	sec--;
	//applying a counter to stop the decrementing of seconds
	if(sec < 0){sec++;}
	else if(sec == 0){
		alert("Times Up!")
	}
	},1100);
}


//adding a shuffle method to the 
Array.prototype.shuffleTiles = function(){
    var i = this.length, j, temp;
    while(--i > 0){
        j = Math.floor(Math.random() * (i+1));
        temp = this[j];
        this[j] = this[i];
        this[i] = temp;
    }
}

//function to shuffle the tiles so that every the page loads div tiles would be in different places
function shuffle(){
	tileFlipped = 0;
	var tileResult = "";
    element.shuffleTiles();
    //Calling of Sound on Click function 
	for(var i = 0; i < element.length; i++){
		//drawing the tile/cards in the game_area by making samll divs and assigning them ids according to the number of elements present in "element" array
		//call divTileFlipped function by passing "this" parameter which represents the current div and element parameter which represents the alphabets present in the element array
		tileResult += '<div id="tile_'+i+'" onclick="PlaySound(); divTileFlipped(this,\''+element[i]+'\')"></div>';
	}
	//drawing the div as cards on game_area
	document.getElementById("game_area2").innerHTML = tileResult;
}

//Background audio

function imageSwitch() {
    var image = document.getElementById("imageMusicOn");
    if (image.src.match("soundOn.png")) {
        image.src = "soundOff.png";
		audio.pause();
    } else {
        image.src = "soundOn.png";
		audio.play();
    }
}

var audio = new Audio("newBackground.mp3" ) ;

audio.oncanplaythrough = function(){
audio.play();
}

audio.loop = true;

audio.onended = function(){
audio.play();
}

//Background audio ends here

//Audio on click

 function PlaySound() {
          var sound = document.getElementById("clickSound");
          sound.play();
      }

//Audio on click ends here

//Audio on Match

function soundOnMatch() {
		var matching = document.getElementById("matchSound");
		matching.play();
}

//Audio on Match ends here

//function to decrease opacity of the tiles which have been matched and the call this function in divTileFlipped function when the tiles are matched
function decreaseOpacity(){
//tile id are pushed in value_array from divTileFlipped funtion	
//popping the last id which was clicked and then using the slice method to slice the second last tile id which is one of the mached tile and decreasing the opacity of that tile
  value_array.pop();
    var length = value_array.length - 1;
    var newTile = value_array.slice(length);
    console.log(value_array.length);
    console.log(newTile);
    document.getElementById(newTile).style.opacity = "0.3";
}


//this function is called whenever a div tile is clicked on the webpage and here tile is the current div which has been clicked and val is the elements from "element" array which are pushed in the div tiles.
function divTileFlipped(tile,val){
	//pushing tile ids which are clicked inside the game area  
        value_array.push(tile.id);
            console.log(value_array);
            //   
	if(tile.innerHTML == "" && elementTileValues.length < 2){
		tile.style.background = "#9ACD32";
		tile.innerHTML = val;
		//this if statement is only executed once when the very first div tile is clicked
		//this if statment pushes the alphabets to elementTileValue 
		if(elementTileValues.length == 0){
			elementTileValues.push(val);
			tileId.push(tile.id);
		} else if(elementTileValues.length == 1){
			elementTileValues.push(val);
			tileId.push(tile.id);

			//When the first and the second alphabets in the elementTileValue are equal then this if statement will be executed
			if(elementTileValues[0] == elementTileValues[1]){
				//the next line of code is executed on one of the matched tiles which is clicked last(the second element's div present in the elementTileValues array)  
                tile.style.opacity = "0.3";
                //decreaseOpacity function is called here to decrese the opacity of the second tile from the matched pair
                decreaseOpacity();
                //now there is one pair of matched tile that means number of tiles flipped is 2 and every time tiles are matched number of tile flipped will increase by 2
                tileFlipped += 2;
                //Calling of Sound on Match function
				
				soundOnMatch();
				// Clear both arrays so that the numbers of elements present in the array equals to 0 so that this code is executed again whenever a new tile is clicked
				elementTileValues = [];
            	tileId = [];
				// next if statement checks that if all the tiles have been flipped(all matches have been made)
				if(tileFlipped == element.length){
					setTimeout(function(){
					alert("Game cleared... shuffling the cards");
					document.getElementById("game_area").innerHTML = "";
					//function to shufflr the cards for the new game
					shuffle();
                    },500);
                    timer();
				}
				//this else statement is executed when 2 tiles are flipped but no match is made
			} else {
				function fliptiles(){
				    // Flip the 2 tiles back over
				    //tileId[0] is the id the first flipped tile and tileId[1] is the second
				    var tile_1 = document.getElementById(tileId[0]);
				    var tile_2 = document.getElementById(tileId[1]);
				    //applying the $ images as the back of the tiles
				    tile_1.style.background = "url(images/cardback_18.png) no-repeat";
				    //clearing the alphabets from the flipped tiles
            	    tile_1.innerHTML = "";
				    tile_2.style.background = "url(images/cardback_18.png) no-repeat";
            	    tile_2.innerHTML = "";
				    // Clear both arrays
            	    tileId = [];
            	    elementTileValues = [];
				}
				setTimeout(fliptiles, 500);
			}
		}
	}
}
